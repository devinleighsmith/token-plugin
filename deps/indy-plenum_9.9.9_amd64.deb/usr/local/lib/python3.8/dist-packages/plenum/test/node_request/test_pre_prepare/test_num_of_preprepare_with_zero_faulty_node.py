nodeCount = 7


def testNumOfPrePrepareWithZeroFaultyNode(preprepared1):
    pass
